import java.util.ArrayList;
import java.util.Scanner;
public class menu {
	
	public static Scanner sc_line = new Scanner(System.in);
	public static Scanner sc = new Scanner(System.in);
	public static ArrayList<materialL> Biblioteca = new ArrayList<materialL>();
	public static int id = 0;
	
	public static void main(String[] args) {
		String eleccion = "0";
		while (!eleccion.equals("9")) {
			System.out.println("---------MENU---------");
			System.out.println("1.Agregar");
			System.out.println("2.Eliminar");
			System.out.println("3.Modificar");
			System.out.println("4.Buscar por titulo");
			System.out.println("5.Buscar por autor");
			System.out.println("6.Buscar por tematica");
			System.out.println("7.Reservar");
			System.out.println("8.Cancelar reserva");
			System.out.println("9.Salir");
			eleccion = sc_line.nextLine();
			switch (eleccion) {
			case "1":
				newMaterial();
				id++;
				break;
			case "2":
				break;
			case "3":
				break;
			case "4":
				break;
			case "5":
				break;
			case "6":
				break;
			case "7":
				break;
			case "8":
				break;
			case "9":
				System.out.println("Saliendo...");
				break;
			}
		}	
	}
	
	
	
	public static void newMaterial() {
		String input;
		do {
			System.out.println("Que quieres agregar: Libro/Revista/Articulo");
			input = sc_line.nextLine();
		} while (!input.equalsIgnoreCase("libro") && !input.equalsIgnoreCase("revista") 
				&& !input.equalsIgnoreCase("articulo"));
		System.out.println("Inserta titulo: ");
		String titulo = sc_line.nextLine();
		System.out.println("Inserta autor: ");
		String autor = sc_line.nextLine();
		System.out.println("Inserta tematica: ");
		String tematica = sc_line.nextLine();
		if (input.equalsIgnoreCase("libro")) {
			String res;
			boolean reserva = false;
			do {
				System.out.println("Esta reservado? SI/NO");
				res = sc_line.nextLine();
			} while (!res.equalsIgnoreCase("SI") && !res.equalsIgnoreCase("NO"));
			if (res.equalsIgnoreCase("si")) {
				reserva = true;
			} else if (res.equalsIgnoreCase("no")) {
				reserva = false;
			}
			libro L = new libro(id, titulo, autor, tematica, reserva);
			System.out.println("Se ha añadido el libro: ");
			L.imprimir();
			Biblioteca.add(L);
		} else if (input.equalsIgnoreCase("revista")) {
			double precio;
			do {
				System.out.println("Que precio es? Mayor que 0");
				precio = sc.nextDouble();
			} while (precio < 0);
			
			revista R = new revista(id, titulo, autor, tematica, precio);
			System.out.println("Se ha añadido la revista: ");
			R.imprimir();
			Biblioteca.add(R);
		} else {
			String disp;
			boolean disponible = false;
			do {
				System.out.println("Esta reservado? SI/NO");
				disp = sc_line.nextLine();
			} while (!disp.equalsIgnoreCase("SI") && !disp.equalsIgnoreCase("NO"));
			if (disp.equalsIgnoreCase("si")) {
				disponible = true;
			} else if (disp.equalsIgnoreCase("no")) {
				disponible = false;
			}
			articulo A = new articulo(id, titulo, autor, tematica, disponible);
			System.out.println("Se ha añadido el articulo: ");
			A.imprimir();
			Biblioteca.add(A);
		}
		
		
		
	}
	
}


